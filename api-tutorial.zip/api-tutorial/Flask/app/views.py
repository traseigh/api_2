from . import app


from bs4 import BeautifulSoup
from flask import Flask, render_template,request, session
import requests
import lxml
import smtplib , ssl
import os
import time
import json
import datetime





@app.route('/')
def index():
    return render_template("index.html")

#After clicking submit
@app.route('/submit', methods=['POST'])
def submit():
    results =[]
    errors=[]
    if request.method == 'POST':
        try:
            courseid = request.form['courseid']
            name = request.form['name']
            url = "https://app.testudo.umd.edu/soc/202008/sections?courseIds="+ courseid.upper() 
            r = requests.get(url)
            soup = BeautifulSoup(r.text,"lxml")
            open_seats =soup.find('span',{'class':'open-seats-count'}).text
            availablity = int(open_seats)
        except:
            errors.append("Enter a valid UMD course number")
            return render_template("index.html", errors = errors)
        if open_seats:
            if availablity >1:
                results.append("Seats available:  " + open_seats)
            elif availablity == 1:
                results.append("Seats available:  " + open_seats)
            else:
                results.append("Sorry, " + name + " no seats found in this course")
    return render_template("index.html",results = results, courseid = courseid, availablity = availablity)


